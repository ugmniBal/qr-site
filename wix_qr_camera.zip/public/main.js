// public/main.js
import { showCameraAndScanQR } from 'backend/qrScanner';

$w.onReady(function () {
    $w('#scanButton').onClick(() => {
        showCameraAndScanQR()
            .then(result => {
                console.log("QR Code Result:", result);
                $w('#qrResult').text = result;
            })
            .catch(error => {
                console.error("QR Scan Error:", error);
            });
    });
});