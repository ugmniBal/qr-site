# Wix QR Code Scanner

This project allows a Wix site to open the camera and scan QR codes using a button click.

## How It Works
- Button click triggers backend function
- Lightbox with camera opens using html5-qrcode
- Scanned result is returned and shown on the page

## Structure
- public/main.js — Page script
- backend/qrScanner.jsw — Backend handler for Lightbox
- lightboxes/QRScanner.html — Lightbox HTML with QR scanner